soroban contract build --profile release-with-logs

